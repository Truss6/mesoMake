package meso;

//import Point;

public class Sys{
	int nPoints;
	Point[] points;
	public Sys(Point[] points){
		this.points = points;
		this.nPoints = points.length;
	}
	public void print(){
		System.out.println("System of "+this.nPoints+" Points");
		for(int i = 0; i < this.nPoints; i++){
			points[i].print();
		}
	}
}
