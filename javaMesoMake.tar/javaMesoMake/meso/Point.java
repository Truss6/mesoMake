package meso;

public class Point{
	double X,Y,R,C;
	int ID;
	public Point(double X, double Y, double R, int ID, double C){
		this.X=X;
		this.Y=Y;
		this.R=R;
		this.ID=ID;
		this.C=C;
	}
	public void print(){
		System.out.print(this.X+",");
		System.out.print(this.Y+"\n");
	}
}
