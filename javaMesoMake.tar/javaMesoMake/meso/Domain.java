package meso;


public class Domain{
	double[] X = new double[2];
	double[] Y = new double[2];
	public double area;
	public Sys system; 
	public Domain(double[] x, double[] y){
		this.X = x;
		this.Y = y;
		this.area = (X[1]-X[0]) * (Y[1]-Y[0]);
	}
	public int update(double h){
		int err = 0;
		int N=this.system.nPoints;
		double x0, y0, r0;
		double dx, dy, dr, d;
		double Fx,Fy,nX,nY;

		for (int i = 0; i<N; i++){
			x0 = this.system.points[i].X;
			y0 = this.system.points[i].Y;
			r0 = this.system.points[i].R;
			Fx=0;Fy=0;
			for (int j = 0; j<N; j++){
				if (i==j){continue;}
				dx = x0 - this.system.points[j].X;
				dy = y0 - this.system.points[j].Y;
				d = Math.sqrt(Math.pow(dx,2) + Math.pow(dy,2));
				dr = r0 + this.system.points[j].R;
				if (d<dr){
					err++;
					nX=dx/d;nY=dy/d;
					Fx+=0.5*h*(dr-d)*nX;
					Fy+=0.5*h*(dr-d)*nY;
				}
			}
			// X-BCs
			if ((x0-r0)<this.X[0]){
				err++;
				Fx+=this.X[0]-(x0-r0);
			}else if((x0+r0)>this.X[1]){
				err++;
				Fx+=this.X[1]-(x0+r0);
			}
			// Y-BCs
			//System.out.println((y0+r0)-this.Y[1]);
			if ((y0-r0)<this.Y[0]){
				err++;
				Fy+=this.Y[0]-(y0-r0);
			}else if((y0+r0)>this.Y[1]){
				err++;
				Fy-=(y0+r0)-this.Y[1];
			}
					
			
			this.system.points[i].X+=Fx;
			this.system.points[i].Y+=Fy;
		}
		return err;
	}
}
