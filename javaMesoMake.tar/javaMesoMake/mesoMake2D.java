//package meso;

import java.util.Random;
import meso.*;

public class mesoMake2D{
	public static void main(String[] args){
		double volFrac1 = 0.8;
		double rad1 = 0.05;

		double[] domainX = new double[]{-200,0};
		double[] domainY = new double[]{0,400};
		Domain D = new Domain(domainX,domainY);
		
		double area1 = volFrac1*D.area;
		int N = (int) Math.floor(area1/Acirc(rad1));

		double[] X = new double[N];
		double[] Y = new double[N];
		double[] R = new double[N];
		int[] ID = new int[N];
		double[] C = new double[N];

		for(int i = 0; i < N; i++){
			X[i] = Math.random()*(domainX[1]-domainX[0])+domainX[0];
			Y[i] = Math.random()*(domainY[1]-domainY[0])+domainX[0];
			R[i] = rad1;
			ID[i] = 0;
			C[i] = 0;
		}

		Point[] points = makePoints(X, Y, R, ID, C);
		D.system = new Sys(points);
		//D.system.print();

		double h = 1.0;
		int err;
		for( int I = 0; I < 100; I++){
			err = D.update(h);
		}
		D.system.print();
	}

	static double Acirc(double r){
		return Math.PI*Math.pow(r,2);
	}

	static Point[] makePoints(double[] x, double[] y, double[] r, int[] id, double[] c){
		Point[] points = new Point[x.length];
		for(int i = 0; i < x.length; i++){
			points[i] = new Point(x[i],y[i],r[i],id[i],c[i]);
		}
		return points;
	}
}
